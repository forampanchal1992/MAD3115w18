//
//  BooksCell.swift
//  Day9Collection
//
//  Created by MacStudent on 2018-03-02.
//  Copyright © 2018 Foram. All rights reserved.
//

import UIKit

class BooksCell: UICollectionViewCell {
    
    @IBOutlet weak var imgBook: UIImageView!
    @IBOutlet weak var lblBookTitle: UILabel!
}
